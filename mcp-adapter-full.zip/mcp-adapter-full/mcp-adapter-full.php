<?php
/**
 * MCP Adapter — Full (Site Abilities) Edition
 *
 * A single, self-contained build that bundles the official WordPress MCP Adapter
 * together with the "MCP Site Abilities" component. In addition to exposing
 * WordPress abilities over MCP, this edition registers abilities that can list and
 * activate themes and read / write / edit / delete files anywhere under
 * wp-content (themes, plugins, mu-plugins, uploads) — so an MCP client can modify
 * plugin and theme code on the site.
 *
 * ⚠ SECURITY: The bundled file-management abilities let an authenticated
 * `manage_options` user change live PHP on the site. Only install this edition on
 * sites you fully trust and control. For a safe, read/execute-only setup, use the
 * "MCP Adapter — Restricted" edition instead.
 *
 * @package     mcp-adapter
 * @author      WordPress.org Contributors
 * @copyright   2025 Plugin Contributors
 * @license     GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       MCP Adapter (Full — Site Abilities)
 * Plugin URI:        https://github.com/ghayasleo/wp-mcp-adapter
 * Description:       MCP Adapter bundled with Site Abilities: exposes WordPress abilities over MCP and adds theme control plus full wp-content file management (read/write/edit/delete code).
 * Version:           0.7.0+full.1.1.1
 * Requires at least: 6.9
 * Requires PHP:      7.4
 * Author:            WordPress.org Contributors
 * Author URI:        https://github.com/WordPress/mcp-adapter/graphs/contributors
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain:       mcp-adapter
 */

declare (strict_types = 1);

namespace WP\MCP;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit();

require_once __DIR__ . '/includes/Autoloader.php';

// If autoloader failed, we cannot proceed.
if ( ! Autoloader::autoload() ) {
	return;
}

// Load the adapter core.
if ( class_exists( Plugin::class ) ) {
	Plugin::instance();
}

// Load the bundled Site Abilities (theme control + wp-content file management).
// This file declares no namespace, so its symbols live in the global namespace.
require_once __DIR__ . '/mcp-site-abilities.php';
